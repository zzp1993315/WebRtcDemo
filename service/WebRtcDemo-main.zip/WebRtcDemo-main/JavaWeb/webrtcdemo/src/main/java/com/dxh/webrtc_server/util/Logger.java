package com.dxh.webrtc_server.util;

public class Logger {
    public static void e(String msg) {
        System.out.println("--------->" + msg);
    }
}
